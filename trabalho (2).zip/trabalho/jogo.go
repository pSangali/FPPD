package main

import (
	"bufio"
	"jogo/network"
	"os"
	"sync"
)

// Elemento representa qualquer objeto do mapa (parede, personagem, vegetação, etc)
type Elemento struct {
	simbolo  rune
	cor      Cor
	corFundo Cor
	tangivel bool // Indica se o elemento bloqueia passagem
}

// Jogo contém o estado atual do jogo
type Jogo struct {
	mu             sync.Mutex
	Mapa           [][]Elemento
	PosX, PosY     int
	UltimoVisitado Elemento
	StatusMsg      string
	PodeMover      bool

	// novo: mapa de players remotos
	RemotePlayers map[string]network.PlayerState
}

// Elementos visuais do jogo
var (
	Personagem = Elemento{'☺', CorCinzaEscuro, CorPadrao, true}
	Parede     = Elemento{'▤', CorParede, CorFundoParede, true}
	Vegetacao  = Elemento{'♣', CorVerde, CorPadrao, true}
	Vazio      = Elemento{' ', CorPadrao, CorPadrao, false}
)

// no jogoNovo(), inicialize o mapa:
func jogoNovo() Jogo {
	return Jogo{
		UltimoVisitado: Vazio,
		PodeMover:      true,
		RemotePlayers:  make(map[string]network.PlayerState),
	}
}

// método para atualizar remotos (retorna joined/left ids para log)
func (j *Jogo) UpdateRemotePlayers(players []network.PlayerState, myPlayerID string) (joined []string, left []string) {
	j.mu.Lock()
	defer j.mu.Unlock()

	seen := make(map[string]bool)
	for _, p := range players {
		// ignora o próprio jogador local
		if p.PlayerID == myPlayerID {
			continue
		}
		seen[p.PlayerID] = true
		if _, ok := j.RemotePlayers[p.PlayerID]; !ok {
			joined = append(joined, p.PlayerID) // novo
		}
		j.RemotePlayers[p.PlayerID] = p
	}

	// detecta left (removidos)
	for id := range j.RemotePlayers {
		if !seen[id] {
			left = append(left, id)
			delete(j.RemotePlayers, id)
		}
	}
	return
}

// Lê um arquivo texto linha por linha e constrói o mapa do jogo
func jogoCarregarMapa(nome string, jogo *Jogo) error {
	arq, err := os.Open(nome)
	if err != nil {
		return err
	}
	defer arq.Close()

	scanner := bufio.NewScanner(arq)
	y := 0
	for scanner.Scan() {
		linha := scanner.Text()
		var linhaElems []Elemento
		for x, ch := range linha {
			e := Vazio
			switch ch {
			case Parede.simbolo:
				e = Parede
			case Vegetacao.simbolo:
				e = Vegetacao
			case Personagem.simbolo:
				// marca posição inicial do personagem e deixa Vazio no mapa (o personagem é desenhado separadamente)
				jogo.PosX, jogo.PosY = x, y
				e = Vazio
			}
			// garantir que linhaElems tenha o mesmo comprimento que a linha de texto
			_ = x
			linhaElems = append(linhaElems, e)
		}
		jogo.Mapa = append(jogo.Mapa, linhaElems)
		y++
	}
	if err := scanner.Err(); err != nil {
		return err
	}
	return nil
}

// Verifica se o personagem pode se mover para a posição (x, y)
func jogoPodeMoverPara(jogo *Jogo, x, y int) bool {
	// Verifica se a coordenada Y está dentro dos limites verticais do mapa
	if y < 0 || y >= len(jogo.Mapa) {
		return false
	}

	// Verifica se a coordenada X está dentro dos limites horizontais do mapa
	if x < 0 || x >= len(jogo.Mapa[y]) {
		return false
	}

	// Verifica se o elemento de destino é tangível (bloqueia passagem)
	if jogo.Mapa[y][x].tangivel {
		return false
	}

	// Pode mover para a posição
	return true
}

// Move um elemento para a nova posição (usa lock do jogo externamente)
func jogoMoverElemento(jogo *Jogo, x, y, dx, dy int) {
	nx, ny := x+dx, y+dy

	// Obtem elemento atual na posição
	elemento := jogo.Mapa[y][x] // guarda o conteúdo atual da posição

	jogo.Mapa[y][x] = jogo.UltimoVisitado   // restaura o conteúdo anterior
	jogo.UltimoVisitado = jogo.Mapa[ny][nx] // guarda o conteúdo atual da nova posição
	jogo.Mapa[ny][nx] = elemento            // move o elemento
}
