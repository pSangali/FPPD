package main

import (
	"math/rand"
	"strconv"
	"time"
)

var Item = Elemento{'*', CorAmarelo, CorPadrao, false}

func iniciarItem(jogo *Jogo, done <-chan struct{}) {
	for {
		select {
		case <-done:
			return
		case <-time.After(8 * time.Second):
			// tenta achar uma posição válida
			var x, y int
			for {
				jogo.mu.Lock()
				y = rand.Intn(len(jogo.Mapa))
				x = rand.Intn(len(jogo.Mapa[y]))
				if !jogo.Mapa[y][x].tangivel { // só em lugar vazio
					// coloca o item no mapa
					jogo.Mapa[y][x] = Item
					jogo.mu.Unlock()
					break
				}
				jogo.mu.Unlock()
			}

			interfaceDesenharJogo(jogo)

			select {
			case <-time.After(8 * time.Second):
				jogo.mu.Lock()
				// se o jogador não pegou, some
				if jogo.PosX != x || jogo.PosY != y {
					jogo.Mapa[y][x] = Vazio
					jogo.StatusMsg = "O item em (" + strconv.Itoa(x) + ", " + strconv.Itoa(y) + ") sumiu: não foi pego a tempo."
					interfaceDesenharBarraDeStatus(jogo)
				}
				jogo.mu.Unlock()
				interfaceDesenharJogo(jogo)
			case <-done:
				return
			}
		}
	}
}
