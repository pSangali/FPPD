//go:build !server
// +build !server

package main

import (
	"fmt"
	"os"
	"sync"
	"time"

	// ajustar import path
	"jogo/network"
)

// variáveis globais para gestão de players remotos
var (
	clientNetwork *network.Client
	localPlayerID string
	remoteMu      sync.Mutex
	remotePlayers = make(map[string]network.PlayerState)
)

func main() {
	// Inicializa interface
	interfaceIniciar()
	defer interfaceFinalizar()

	// Define arquivo de mapa
	mapaFile := "mapa.txt"
	if len(os.Args) > 1 {
		mapaFile = os.Args[1]
	}

	// Cria jogo e carrega mapa
	jogo := jogoNovo()
	if err := jogoCarregarMapa(mapaFile, &jogo); err != nil {
		panic(err)
	}

	interfaceDesenharJogo(&jogo)

	// --- inicia elementos concorrentes ---
	done := make(chan struct{})
	time.Sleep(1 * time.Millisecond)
	go iniciarItem(&jogo, done)

	// --- inicializa cliente de rede (opcional) ---
	// Gera playerID único para evitar sobrescrita no servidor
	localPlayerID = fmt.Sprintf("player-%d-%d", time.Now().UnixNano(), os.Getpid())

	clientNetwork = network.NewClient("26.188.20.55:12345", localPlayerID, "Jogador", 300*time.Millisecond)

	// callback para aplicar estado remoto (players). Deve ser thread-safe.
	clientNetwork.ApplyRemoteState = func(players []network.PlayerState) {
		joined, left := updateRemotePlayers(players)

		for _, id := range joined {
			fmt.Printf("[NET] player entrou: %s\n", id)
		}
		for _, id := range left {
			fmt.Printf("[NET] player saiu: %s\n", id)
		}

		// redesenha para refletir mudanças imediatamente
		interfaceDesenharJogo(&jogo)
	}

	// tenta registrar (connect)
	if _, err := clientNetwork.Register(jogo.PosX, jogo.PosY); err != nil {
		fmt.Printf("[NET] Warning: não foi possível registrar no servidor: %v\n", err)
		// prossegue offline (jogo continua localmente)
	}

	// --- loop principal do jogador ---
	for {
		evento := interfaceLerEventoTeclado() // lê tecla
		if continuar := personagemExecutarAcao(evento, &jogo); !continuar {
			break // sai do jogo se ESC
		}
		interfaceDesenharJogo(&jogo) // redesenha jogo a cada ação
	}

	// --- ao sair do jogo, sinaliza para parar as goroutines e fecha client ---
	close(done)
	if clientNetwork != nil {
		clientNetwork.Stop()
	}
}

// updateRemotePlayers atualiza o mapa global remotePlayers e retorna slices com ids que entraram e saíram
func updateRemotePlayers(players []network.PlayerState) (joined []string, left []string) {
	remoteMu.Lock()
	defer remoteMu.Unlock()

	seen := make(map[string]bool)
	for _, p := range players {
		seen[p.PlayerID] = true
		// ignora o próprio jogador local
		if p.PlayerID == localPlayerID {
			continue
		}
		if _, ok := remotePlayers[p.PlayerID]; !ok {
			joined = append(joined, p.PlayerID)
		}
		remotePlayers[p.PlayerID] = p
	}

	// detecta players que saíram
	for id := range remotePlayers {
		if !seen[id] {
			left = append(left, id)
			delete(remotePlayers, id)
		}
	}
	return
}
