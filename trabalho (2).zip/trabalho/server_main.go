//go:build server
// +build server

package main

import (
	"log"
	"time"

	"jogo/network"
)

func main() {
	s := network.NewServer(":12345")
	if err := s.Start(); err != nil {
		log.Fatalf("erro ao iniciar servidor: %v", err)
	}
	log.Printf("[SERVER MAIN] servidor iniciado em :12345")
	// mantém o processo vivo
	for {
		time.Sleep(1 * time.Hour)
	}
}
