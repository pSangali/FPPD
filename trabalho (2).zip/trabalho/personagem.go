package main

import (
	"fmt"
	"strconv"
	"time"

	// ajuste o import path do network conforme seu module no go.mod
	"jogo/network"
)

var itensPegos int // contador global de itens

// Observação: clientNetwork deve ser inicializado no main e ser visível aqui.
// Eu suponho que exista uma variável global (apenas para integração simples).

// Move o personagem com base na tecla pressionada (WASD)
func personagemMover(tecla rune, jogo *Jogo) {
	if !jogo.PodeMover {
		jogo.StatusMsg = "Você não pode se mover, foi pego!"
		interfaceDesenharBarraDeStatus(jogo)
		return
	}

	dx, dy := 0, 0
	switch tecla {
	case 'w':
		dy = -1
	case 'a':
		dx = -1
	case 's':
		dy = 1
	case 'd':
		dx = 1
	}

	jogo.mu.Lock()
	nx, ny := jogo.PosX+dx, jogo.PosY+dy
	if jogoPodeMoverPara(jogo, nx, ny) {
		jogoMoverElemento(jogo, jogo.PosX, jogo.PosY, dx, dy)
		jogo.PosX, jogo.PosY = nx, ny
	}
	jogo.mu.Unlock()

	// desenha imediatamente para responsividade
	interfaceDesenharJogo(jogo)

	// envia comando ao servidor (não bloqueante idealmente; aqui chamamos de forma assíncrona)
	if clientNetwork != nil {
		payload := fmt.Sprintf("%d:%d", nx, ny)
		cmd := network.Command{
			Type:       network.CmdMove,
			Payload:    payload,
			ClientTime: time.Now().UnixMilli(),
		}
		// enviar em goroutine para não bloquear o loop de input
		go func() {
			if _, err := clientNetwork.SendCommand(cmd); err != nil {
				// apenas logue (para não atrapalhar a experiência)
				// em produção, você pode exibir mensagem ao jogador
				fmt.Printf("[NET] erro enviando comando: %v\n", err)
			}
		}()
	}
}

// Define o que ocorre quando o jogador pressiona a tecla de interação
func personagemInteragir(jogo *Jogo) {
	jogo.mu.Lock()
	if jogo.UltimoVisitado.simbolo == Item.simbolo {
		itensPegos++
		jogo.StatusMsg = "Você pegou o item! Total: " + strconv.Itoa(itensPegos)
		jogo.UltimoVisitado = Vazio
	} else {
		jogo.StatusMsg = "Não há item aqui."
	}
	jogo.mu.Unlock()

	interfaceDesenharBarraDeStatus(jogo)
	interfaceDesenharJogo(jogo)

	// notifica servidor sobre a ação de pegar (ACTION)
	if clientNetwork != nil {
		cmd := network.Command{
			Type:       network.CmdAction,
			Payload:    "PICK_ITEM",
			ClientTime: time.Now().UnixMilli(),
		}
		go func() {
			if _, err := clientNetwork.SendCommand(cmd); err != nil {
				fmt.Printf("[NET] erro enviando action: %v\n", err)
			}
		}()
	}
}

func personagemExecutarAcao(ev EventoTeclado, jogo *Jogo) bool {
	switch ev.Tipo {
	case "sair":
		return false
	case "interagir":
		personagemInteragir(jogo)
	case "mover":
		personagemMover(ev.Tecla, jogo)
	}
	return true
}
