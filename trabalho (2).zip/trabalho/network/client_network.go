package network

import (
	"fmt"
	"net/rpc"
	"sync"
	"time"
)

// Client RPC para integrar ao jogo.
type Client struct {
	rpcAddr     string
	rpcClient   *rpc.Client
	playerID    string
	displayName string

	mu       sync.Mutex
	seq      int64
	pending  map[int64]SendCommandArgs
	stopPoll chan struct{}
	pollFreq time.Duration

	// Callback para aplicar estado remoto no jogo.
	ApplyRemoteState func([]PlayerState)
}

func NewClient(rpcAddr, playerID, displayName string, pollFreq time.Duration) *Client {
	return &Client{
		rpcAddr:     rpcAddr,
		playerID:    playerID,
		displayName: displayName,
		pending:     make(map[int64]SendCommandArgs),
		pollFreq:    pollFreq,
		stopPoll:    make(chan struct{}),
	}
}

func (c *Client) Connect() error {
	client, err := rpc.Dial("tcp", c.rpcAddr)
	if err != nil {
		return err
	}
	c.rpcClient = client
	// LOG REMOVIDO
	return nil
}

func (c *Client) Register(initX, initY int) (*RegisterReply, error) {
	if c.rpcClient == nil {
		if err := c.Connect(); err != nil {
			return nil, err
		}
	}
	args := RegisterArgs{
		PlayerID:    c.playerID,
		DisplayName: c.displayName,
		InitX:       initX,
		InitY:       initY,
	}
	var reply RegisterReply
	err := c.rpcClient.Call("Server.RegisterPlayer", &args, &reply)
	if err != nil {
		// LOG REMOVIDO
		return nil, err
	}
	// LOG REMOVIDO
	go c.startPoller()
	return &reply, nil
}

func (c *Client) SendCommand(cmd Command) (*SendCommandReply, error) {
	c.mu.Lock()
	c.seq++
	seq := c.seq
	cmd.SequenceNumber = seq
	args := SendCommandArgs{
		PlayerID: c.playerID,
		Command:  cmd,
	}
	c.pending[seq] = args
	c.mu.Unlock()

	var lastErr error
	backoff := 200 * time.Millisecond
	for attempts := 0; attempts < 6; attempts++ {
		if c.rpcClient == nil {
			if err := c.Connect(); err != nil {
				lastErr = err
				time.Sleep(backoff)
				backoff *= 2
				continue
			}
		}
		var reply SendCommandReply
		callErr := c.rpcClient.Call("Server.SendCommand", &args, &reply)
		if callErr == nil {
			c.mu.Lock()
			delete(c.pending, seq)
			c.mu.Unlock()
			// LOG REMOVIDO
			return &reply, nil
		}
		lastErr = callErr
		// LOG REMOVIDO
		time.Sleep(backoff)
		backoff *= 2
	}
	return nil, fmt.Errorf("sendcommand failed after retries: %v", lastErr)
}

func (c *Client) startPoller() {
	ticker := time.NewTicker(c.pollFreq)
	defer ticker.Stop()
	// LOG REMOVIDO
	for {
		select {
		case <-ticker.C:
			c.doPoll()
		case <-c.stopPoll:
			// LOG REMOVIDO
			return
		}
	}
}

func (c *Client) doPoll() {
	args := GetStateArgs{
		PlayerID:        c.playerID,
		LastKnownServer: 0,
	}
	var reply GetStateReply
	if c.rpcClient == nil {
		if err := c.Connect(); err != nil {
			// LOG REMOVIDO
			return
		}
	}
	err := c.rpcClient.Call("Server.GetState", &args, &reply)
	if err != nil {
		// LOG REMOVIDO
		return
	}
	// LOG REMOVIDO
	if c.ApplyRemoteState != nil {
		c.ApplyRemoteState(reply.Players)
	}
}

func (c *Client) Stop() {
	close(c.stopPoll)
	if c.rpcClient != nil {
		_ = c.rpcClient.Close()
	}
}
