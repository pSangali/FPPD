INSTRUÇÕES DE INTEGRAÇÃO (resumo)

1) Estrutura:
   - Coloque os arquivos do módulo network em trabalho/network/.
   - Ajuste seu go.mod para conter o module path correto (ex: module github.com/voce/trabalho)
   - Nos arquivos do jogo (main.go, personagem.go) importe o pacote network com o path do seu module:
       import "github.com/voce/trabalho/network"
     (ou: import "trabalho/network" se você usou 'module trabalho' no go.mod)

2) Iniciar servidor (opcional localmente):
   - Crie um pequeno main separado para rodar o servidor, ou execute dentro do seu binário principal, por exemplo:
       s := network.NewServer(":12345")
       if err := s.Start(); err != nil { panic(err) }

3) No main do jogo (cliente):
   - Crie client := network.NewClient("127.0.0.1:12345", myPlayerID, myName, 200*time.Millisecond)
   - Opcional: client.ApplyRemoteState = func(players []network.PlayerState) { Game.ApplyRemoteState(players) }
     (vou mostrar um exemplo de implementação de ApplyRemoteState no README do projeto)
   - Faça client.Register(initX, initY) no início e client.Stop() ao sair.

4) Hooks para integrar (onde já alterei no código):
   - Ao mover o personagem localmente (personagemMover), após aplicar a movimentação local, crie um Command:
       cmd := network.Command{Type: network.CmdMove, Payload: fmt.Sprintf("%d:%d", newX, newY), ClientTime: time.Now().UnixMilli()}
       client.SendCommand(cmd)
   - Ao interagir (pegar item), envie um Command tipo ACTION com payload descritivo.

5) Thread-safety:
   - O jogo agora tem um mutex interno (jogo.mu). Qualquer callback do cliente que modifica jogo deve usar jogo.mu.Lock()/Unlock().

6) Tests:
   - Veja tests_plan.md no diretório root para lista de cenários (register, sendcommand, duplicates, server restart).

