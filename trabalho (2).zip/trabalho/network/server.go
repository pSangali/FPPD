package network

import (
	"errors"
	"fmt"
	"log"
	"net"
	"net/rpc"
	"sync"
	"time"
)

type Server struct {
	mu                 sync.RWMutex
	players            map[string]PlayerState
	processedSequences map[string]int64
	serverVersion      int64
	addr               string
	Players            map[string]*PlayerState
}

func NewServer(addr string) *Server {
	return &Server{
		players:            make(map[string]PlayerState),
		processedSequences: make(map[string]int64),
		serverVersion:      1,
		addr:               addr,
	}
}

func (s *Server) Start() error {
	rpc.RegisterName("Server", s)
	ln, err := net.Listen("tcp", s.addr)
	if err != nil {
		return err
	}
	log.Printf("[SERVER] Listening on %s\n", s.addr)
	go func() {
		for {
			conn, err := ln.Accept()
			if err != nil {
				log.Printf("[SERVER] Accept error: %v\n", err)
				continue
			}
			go rpc.ServeConn(conn)
		}
	}()
	return nil
}

func (s *Server) RegisterPlayer(args *RegisterArgs, reply *RegisterReply) error {
	log.Printf("[SERVER] RegisterPlayer: %+v\n", args)
	if args.PlayerID == "" {
		reply.Success = false
		reply.Error = "empty playerID"
		return errors.New(reply.Error)
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	s.players[args.PlayerID] = PlayerState{
		PlayerID:    args.PlayerID,
		DisplayName: args.DisplayName,
		X:           args.InitX,
		Y:           args.InitY,
		Lives:       3,
		LastSeen:    time.Now(),
	}
	s.processedSequences[args.PlayerID] = 0
	s.serverVersion++

	players := make([]PlayerState, 0, len(s.players))
	for _, p := range s.players {
		players = append(players, p)
	}
	reply.Success = true
	reply.AssignedID = args.PlayerID
	reply.ServerTime = time.Now().UnixMilli()
	reply.InitialState = players
	log.Printf("[SERVER] RegisterPlayer reply: success for %s\n", args.PlayerID)
	return nil
}

func (s *Server) UnregisterPlayer(args *UnregisterArgs, reply *UnregisterReply) error {
	log.Printf("[SERVER] UnregisterPlayer: %+v\n", args)
	s.mu.Lock()
	defer s.mu.Unlock()
	delete(s.players, args.PlayerID)
	delete(s.processedSequences, args.PlayerID)
	s.serverVersion++
	reply.Success = true
	return nil
}

func (s *Server) SendCommand(args *SendCommandArgs, reply *SendCommandReply) error {
	log.Printf("[SERVER] SendCommand from %s seq=%d type=%s payload=%s\n",
		args.PlayerID, args.Command.SequenceNumber, args.Command.Type, args.Command.Payload)
	s.mu.Lock()
	defer s.mu.Unlock()

	if _, ok := s.players[args.PlayerID]; !ok {
		reply.ProcessedSequence = 0
		reply.Result = "INVALID_PLAYER"
		reply.Error = "player not registered"
		return errors.New(reply.Error)
	}

	last := s.processedSequences[args.PlayerID]
	seq := args.Command.SequenceNumber

	if seq <= last {
		reply.ProcessedSequence = last
		reply.Result = "IGNORED_DUPLICATE"
		reply.ServerVersion = s.serverVersion
		log.Printf("[SERVER] Duplicate command ignored: player=%s seq=%d last=%d\n", args.PlayerID, seq, last)
		return nil
	}

	// Se MOVE, parse payload "x:y" e atualiza posição registrada (sanity check)
	if args.Command.Type == CmdMove {
		var nx, ny int
		n, err := fmt.Sscanf(args.Command.Payload, "%d:%d", &nx, &ny)
		if err == nil && n == 2 {
			cur := s.players[args.PlayerID]
			// sanity check de distância (exemplo)
			dx := nx - cur.X
			dy := ny - cur.Y
			dist2 := dx*dx + dy*dy
			if dist2 > 100000000 { // salto absurdo -> inválido
				reply.ProcessedSequence = last
				reply.Result = "INVALID"
				reply.Error = "move implausible"
				return errors.New(reply.Error)
			}
			cur.X = nx
			cur.Y = ny
			cur.LastSeen = time.Now()
			s.players[args.PlayerID] = cur
		}
	} else {
		cur := s.players[args.PlayerID]
		cur.LastSeen = time.Now()
		s.players[args.PlayerID] = cur
	}

	s.processedSequences[args.PlayerID] = seq
	s.serverVersion++

	reply.ProcessedSequence = seq
	reply.Result = "OK"
	reply.ServerVersion = s.serverVersion
	log.Printf("[SERVER] Command processed: player=%s seq=%d newServerVersion=%d\n", args.PlayerID, seq, s.serverVersion)
	return nil
}

func (s *Server) GetState(args *GetStateArgs, reply *GetStateReply) error {
	log.Printf("[SERVER] GetState from %s lastKnown=%d\n", args.PlayerID, args.LastKnownServer)
	s.mu.RLock()
	defer s.mu.RUnlock()
	players := make([]PlayerState, 0, len(s.players))
	for _, p := range s.players {
		players = append(players, p)
	}
	reply.ServerVersion = s.serverVersion
	reply.Players = players
	return nil
}
