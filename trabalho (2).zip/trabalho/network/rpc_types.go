package network

import "time"

// Tipos RPC básicos para comunicar posição e comandos simples.

type PlayerState struct {
	PlayerID    string    `json:"player_id"`
	DisplayName string    `json:"display_name"`
	X           int       `json:"x"`
	Y           int       `json:"y"`
	Lives       int       `json:"lives"`
	LastSeen    time.Time `json:"last_seen"`
}

type CommandType string

const (
	CmdMove   CommandType = "MOVE"
	CmdAction CommandType = "ACTION"
)

type Command struct {
	SequenceNumber int64       `json:"seq"`
	Type           CommandType `json:"type"`
	Payload        string      `json:"payload"`     // ex: "x:y" para MOVE
	ClientTime     int64       `json:"client_time"` // unix millis
}

// Register
type RegisterArgs struct {
	PlayerID    string `json:"player_id"`
	DisplayName string `json:"display_name"`
	InitX       int    `json:"init_x"`
	InitY       int    `json:"init_y"`
}
type RegisterReply struct {
	Success      bool          `json:"success"`
	AssignedID   string        `json:"assigned_id"`
	ServerTime   int64         `json:"server_time"`
	InitialState []PlayerState `json:"initial_state"`
	Error        string        `json:"error,omitempty"`
}

// Unregister
type UnregisterArgs struct {
	PlayerID string `json:"player_id"`
}
type UnregisterReply struct {
	Success bool   `json:"success"`
	Error   string `json:"error,omitempty"`
}

// SendCommand
type SendCommandArgs struct {
	PlayerID string  `json:"player_id"`
	Command  Command `json:"command"`
}
type SendCommandReply struct {
	ProcessedSequence int64  `json:"processed_sequence"`
	Result            string `json:"result"`
	ServerVersion     int64  `json:"server_version"`
	Error             string `json:"error,omitempty"`
}

// GetState
type GetStateArgs struct {
	PlayerID        string `json:"player_id"`
	LastKnownServer int64  `json:"last_known_server"`
}
type GetStateReply struct {
	ServerVersion int64         `json:"server_version"`
	Players       []PlayerState `json:"players"`
	Error         string        `json:"error,omitempty"`
}
